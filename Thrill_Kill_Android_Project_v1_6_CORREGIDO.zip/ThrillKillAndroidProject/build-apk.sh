#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.9 no está instalado. Usa Android Studio o el workflow de GitHub Actions incluido."
  exit 1
fi
exec gradle --no-daemon :app:assembleDebug

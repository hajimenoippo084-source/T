THRILL KILL ANDROID v1.6

REQUISITOS
- Android ARM64 (arm64-v8a).
- Archivo de juego PS1 propio en CHD, ISO, PBP o IMG.
- Conexión a Internet solo durante la compilación de GitHub Actions para descargar dependencias y el núcleo. Después de instalar, el juego se ejecuta sin conexión.

MOTOR
La aplicación utiliza LibretroDroid como frontend Android y PCSX-ReARMed como núcleo Libretro. El núcleo se descarga desde el Buildbot de Libretro durante la compilación y queda empaquetado como asset privado de la APK.

USO
1. Abre THRILL KILL.
2. Selecciona el archivo del juego una sola vez.
3. Pulsa INICIAR CAZA. La primera apertura copia el juego a la carpeta privada de la app.
4. Los controles aparecen solamente durante la partida.
5. Los guardados normales del juego se escriben en el directorio SaveRAM de PCSX-ReARMed.

CARÁTULA
La carátula personalizada se elige en el menú y es independiente del icono Android.

BIOS
PCSX-ReARMed puede iniciar con BIOS HLE. La compatibilidad puede variar. Algunos juegos pueden necesitar BIOS de PS1 obtenida legalmente desde el hardware propio; el proyecto no incluye BIOS.

COMPILACIÓN
El archivo .github/workflows/build-apk.yml instala Android SDK, descarga PCSX-ReARMed ARM64 y ejecuta gradlew assembleDebug. El artefacto resultante es un APK debug.

LICENCIAS
LibretroDroid: GPL-3.0 https://github.com/Swordfish90/LibretroDroid
PCSX-ReARMed: GPL-2.0 https://github.com/libretro/pcsx_rearmed
La redistribución del código fuente debe respetar las licencias de ambos proyectos.

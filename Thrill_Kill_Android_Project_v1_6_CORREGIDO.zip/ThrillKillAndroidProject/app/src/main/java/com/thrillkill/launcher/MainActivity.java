package com.thrillkill.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.util.Log;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int GAME_PICKER_REQUEST = 7302;
    private static final int COVER_PICKER_REQUEST = 7303;
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String PREFS = "thrill_kill_preferences";
    private static final String PREF_GAME_URI = "selected_game_uri";
    private static final String PREF_GAME_NAME = "selected_game_name";
    private static final String PREF_GAME_SIZE = "selected_game_size";
    private static final String PREF_COVER_URI = "selected_cover_uri";
    private static final String PREF_PERFORMANCE = "performance_profile";

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        applyImmersiveMode();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.addJavascriptInterface(new LauncherBridge(), "ThrillKillNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (ASSET_HOST.equals(uri.getHost()) && uri.getPath() != null && uri.getPath().startsWith("/assets/")) {
                    String assetPath = uri.getPath().substring("/assets/".length());
                    try {
                        InputStream stream = getAssets().open(assetPath);
                        String mime = URLConnection.guessContentTypeFromName(assetPath);
                        if (mime == null) {
                            if (assetPath.endsWith(".html")) mime = "text/html";
                            else if (assetPath.endsWith(".js")) mime = "application/javascript";
                            else if (assetPath.endsWith(".css")) mime = "text/css";
                            else if (assetPath.endsWith(".svg")) mime = "image/svg+xml";
                            else mime = "application/octet-stream";
                        }
                        String encoding = (mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json")) ? "UTF-8" : null;
                        return new WebResourceResponse(mime, encoding, stream);
                    } catch (IOException e) {
                        Log.e("ThrillKill", "Asset not found: " + assetPath, e);
                        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", Collections.emptyMap(),
                                new ByteArrayInputStream("Local asset not found".getBytes()));
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (ASSET_HOST.equals(uri.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (Exception e) { Log.w("ThrillKill", "No app can open link", e); }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("window.restoreNativeSettings && window.restoreNativeSettings();", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("https://" + ASSET_HOST + "/assets/index.html");
    }

    private Uri getSavedGameUri() {
        String value = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_GAME_URI, null);
        if (value == null || value.isEmpty()) return null;
        try { return Uri.parse(value); } catch (Exception e) { return null; }
    }

    private String getSavedGameName() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_GAME_NAME, "");
    }

    private long getSavedGameSize() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getLong(PREF_GAME_SIZE, 0L);
    }

    private void launchCoverPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, COVER_PICKER_REQUEST);
    }

    private Uri getSavedCoverUri() {
        String value = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_COVER_URI, null);
        if (value == null || value.isEmpty()) return null;
        try { return Uri.parse(value); } catch (Exception e) { return null; }
    }

    private String getCoverImageData() {
        Uri uri = getSavedCoverUri();
        if (uri == null) return "";
        try (InputStream input = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            if (input == null) return "";
            byte[] buffer = new byte[8192];
            int read;
            int total = 0;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > 8 * 1024 * 1024) return "";
                output.write(buffer, 0, read);
            }
            String mime = getContentResolver().getType(uri);
            if (mime == null || !mime.startsWith("image/")) mime = "image/jpeg";
            return "data:" + mime + ";base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            Log.w("ThrillKill", "Could not read saved cover", e);
            return "";
        }
    }

    private void clearSavedCover() {
        Uri uri = getSavedCoverUri();
        if (uri != null) {
            try { getContentResolver().releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(PREF_COVER_URI).apply();
    }

    private String getPerformanceProfile() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_PERFORMANCE, "balanced");
    }

    private void setPerformanceProfile(String profile) {
        if (!("eco".equals(profile) || "balanced".equals(profile) || "performance".equals(profile))) profile = "balanced";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_PERFORMANCE, profile).apply();
    }

    private void launchGamePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/octet-stream", "application/x-chd", "application/x-iso9660-image", "application/x-cue"
        });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, GAME_PICKER_REQUEST);
    }

    private String queryDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {}
        String segment = uri.getLastPathSegment();
        return segment == null ? "Juego PS1" : segment;
    }

    private long queryFileSize(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index);
            }
        } catch (Exception ignored) {}
        return 0L;
    }

    private boolean isSupportedGameName(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".chd") || lower.endsWith(".iso") || lower.endsWith(".cue")
                || lower.endsWith(".bin") || lower.endsWith(".pbp") || lower.endsWith(".img");
    }

    private String mimeForGame(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".chd")) return "application/x-chd";
        if (lower.endsWith(".cue")) return "application/x-cue";
        if (lower.endsWith(".iso")) return "application/x-iso9660-image";
        return "application/octet-stream";
    }

    private void launchSavedGame() {
        final Uri gameUri = getSavedGameUri();
        if (gameUri == null) {
            notifyJs("Selecciona primero tu archivo de PlayStation.");
            return;
        }
        final String name = getSavedGameName();
        final String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".cue") || lower.endsWith(".bin")) {
            notifyJs("Para esta versión integrada selecciona el CHD, ISO o PBP del juego. Los CUE/BIN necesitan copiar juntos todos sus archivos.");
            return;
        }
        if (!hasArm64Support()) {
            notifyJs("Esta versión del motor está preparada para Android ARM64.");
            return;
        }
        notifyJs("Copiando el juego al almacenamiento privado y preparando PCSX-ReARMed...");
        new Thread(() -> {
            try {
                File gameFile = copySelectedGameIntoApp(gameUri, name);
                runOnUiThread(() -> {
                    Intent intent = new Intent(MainActivity.this, EmulationActivity.class);
                    intent.putExtra(EmulationActivity.EXTRA_GAME_PATH, gameFile.getAbsolutePath());
                    intent.putExtra(EmulationActivity.EXTRA_GAME_TITLE, name);
                    startActivity(intent);
                });
            } catch (Exception e) {
                Log.e("ThrillKill", "Could not prepare selected game", e);
                notifyJs("No se pudo preparar el juego. Comprueba que el archivo siga disponible y vuelve a seleccionarlo.");
            }
        }, "ThrillKill-GameCopy").start();
    }

    private boolean hasArm64Support() {
        for (String abi : Build.SUPPORTED_ABIS) {
            if ("arm64-v8a".equals(abi)) return true;
        }
        return false;
    }

    private File copySelectedGameIntoApp(Uri uri, String displayName) throws IOException {
        File gameDirectory = new File(getFilesDir(), "games/ps1");
        if (!gameDirectory.exists() && !gameDirectory.mkdirs()) {
            throw new IOException("No se pudo crear la carpeta de juegos");
        }
        String safeName = displayName == null ? "thrill-kill.chd" : displayName.replaceAll("[^A-Za-z0-9._ -]", "_");
        if (safeName.trim().isEmpty()) safeName = "thrill-kill.chd";
        String id = Integer.toHexString(uri.toString().hashCode());
        File destination = new File(gameDirectory, id + "_" + safeName);
        long sourceSize = queryFileSize(uri);
        if (destination.isFile() && sourceSize > 0 && destination.length() == sourceSize) {
            return destination;
        }
        File temporary = new File(destination.getAbsolutePath() + ".part");
        try (InputStream input = getContentResolver().openInputStream(uri);
             FileOutputStream output = new FileOutputStream(temporary)) {
            if (input == null) throw new IOException("El proveedor no pudo abrir el archivo");
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            output.flush();
        } catch (Exception e) {
            temporary.delete();
            if (e instanceof IOException) throw (IOException) e;
            throw new IOException("Error al copiar el juego", e);
        }
        if (destination.exists() && !destination.delete()) {
            temporary.delete();
            throw new IOException("No se pudo reemplazar la copia anterior");
        }
        if (!temporary.renameTo(destination)) {
            temporary.delete();
            throw new IOException("No se pudo completar la copia del juego");
        }
        return destination;
    }

    private void notifyJs(String message) {
        if (webView != null) webView.post(() -> webView.evaluateJavascript(
                "window.setNativeStatus && window.setNativeStatus(" + JSONObject.quote(message) + ");", null));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == COVER_PICKER_REQUEST) {
            String mime = getContentResolver().getType(uri);
            if (mime == null || !mime.startsWith("image/")) {
                notifyJs("Selecciona un archivo de imagen para la carátula.");
                return;
            }
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception e) {
                Log.w("ThrillKill", "Could not persist cover permission", e);
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_COVER_URI, uri.toString()).apply();
            if (webView != null) webView.post(() -> webView.evaluateJavascript("window.restoreNativeSettings && window.restoreNativeSettings();", null));
            notifyJs("Carátula guardada. No cambia el icono de la aplicación.");
            return;
        }
        if (requestCode == GAME_PICKER_REQUEST) {
            String name = queryDisplayName(uri);
            if (!isSupportedGameName(name)) {
                notifyJs("Formato no reconocido. Selecciona CHD, ISO, CUE, BIN, PBP o IMG.");
                return;
            }
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception e) {
                Log.w("ThrillKill", "Could not persist selected game permission", e);
            }
            long size = queryFileSize(uri);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(PREF_GAME_URI, uri.toString())
                    .putString(PREF_GAME_NAME, name)
                    .putLong(PREF_GAME_SIZE, size)
                    .apply();
            if (webView != null) {
                String js = "window.onNativeGameSelected && window.onNativeGameSelected(" + JSONObject.quote(name) + "," + size + ");";
                webView.post(() -> webView.evaluateJavascript(js, null));
            }
        }
    }

    private void applyImmersiveMode() {
        View decor = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decor.setSystemUiVisibility(flags);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override public void onBackPressed() { super.onBackPressed(); }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("ThrillKillNative");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private class LauncherBridge {
        @JavascriptInterface public void pickGameFile() {
            runOnUiThread(() -> {
                try { launchGamePicker(); }
                catch (Exception e) { notifyJs("Android no pudo abrir el selector de juegos."); }
            });
        }
        @JavascriptInterface public void launchSavedGame() {
            runOnUiThread(MainActivity.this::launchSavedGame);
        }
        @JavascriptInterface public void pickCoverFile() {
            runOnUiThread(() -> {
                try { launchCoverPicker(); }
                catch (Exception e) { notifyJs("Android no pudo abrir el selector de carátulas."); }
            });
        }
        @JavascriptInterface public void clearCover() {
            runOnUiThread(() -> { clearSavedCover(); notifyJs("Carátula personalizada eliminada."); });
        }
        @JavascriptInterface public String getCoverImageData() { return MainActivity.this.getCoverImageData(); }
        @JavascriptInterface public String getPerformanceProfile() { return MainActivity.this.getPerformanceProfile(); }
        @JavascriptInterface public void setPerformanceProfile(String profile) { MainActivity.this.setPerformanceProfile(profile); }
        @JavascriptInterface public String getSavedGameName() { return MainActivity.this.getSavedGameName(); }
        @JavascriptInterface public long getSavedGameSize() { return MainActivity.this.getSavedGameSize(); }
        @JavascriptInterface public boolean hasSavedGame() { return getSavedGameUri() != null; }
    }
}

@echo off
setlocal
set VERSION=8.9
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set DIST_HOME=%GRADLE_USER_HOME%\thrillkill-bootstrap\gradle-%VERSION%
set GRADLE_BIN=%DIST_HOME%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_USER_HOME%\thrillkill-bootstrap" mkdir "%GRADLE_USER_HOME%\thrillkill-bootstrap"
  echo Descargando Gradle %VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip'; $z='%GRADLE_USER_HOME%\thrillkill-bootstrap\gradle-%VERSION%-bin.zip'; Invoke-WebRequest -Uri $u -OutFile $z; Expand-Archive -Path $z -DestinationPath '%GRADLE_USER_HOME%\thrillkill-bootstrap' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
